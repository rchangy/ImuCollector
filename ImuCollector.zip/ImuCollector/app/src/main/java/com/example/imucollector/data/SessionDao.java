package com.example.imucollector.data;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Index;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.imucollector.data.Session;

@Dao
public interface SessionDao {
    @Insert
    public void insertSessions(Session... sessions);

    @Delete
    public void deleteSessions(Session... sessions);

    @Query("SELECT * FROM session")
    public Session[] getAll();
}
