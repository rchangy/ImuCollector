package com.example.imucollector.data;

import java.util.Date;

public class SensorData {

    private double x;
    private double y;
    private double z;

    private long timeIntv;
    private Date timestamp;

    public SensorData(long timeIntv){
        this.timeIntv = timeIntv;
        timestamp = new Date(timeIntv);
    }

    public void setData(double x, double y, double z){
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public String[] formatData(){
        String[] ret = {String.valueOf(timeIntv), String.valueOf(x), String.valueOf(y), String.valueOf(z)};
        return ret;
    }
}
