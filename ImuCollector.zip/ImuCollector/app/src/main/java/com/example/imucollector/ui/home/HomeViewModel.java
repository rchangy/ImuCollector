package com.example.imucollector.ui.home;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;


import android.app.Application;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.support.v4.provider.DocumentFile;

import androidx.lifecycle.SavedStateHandle;

import com.example.imucollector.data.SensorData;
import com.example.imucollector.data.Session;
import com.example.imucollector.data.SessionDao;
import com.example.imucollector.data.SessionDatabase;
import com.opencsv.CSVWriter;

import org.w3c.dom.Document;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class HomeViewModel extends AndroidViewModel implements SensorEventListener {
    private SavedStateHandle savedStateHandle;

    public MutableLiveData<Integer> currentFreq;
    public MutableLiveData<Integer> currentId;
    public MutableLiveData<Integer> currentRecordId;

    public MutableLiveData<Boolean> isCollecting = new MutableLiveData<>(false);

    // data collecting
    private Session currentSession;
    private ArrayList<SensorData> accData;
    private ArrayList<SensorData> gyroData;

    // sensors
    private SensorManager sensorManager;
    private Sensor accSensor;
    private Sensor gyroSensor;
//    private Sensor magSensor;

    // database
    private SessionDatabase db = SessionDatabase.getInstance(getApplication());
    private SessionDao sessionDao = db.sessionDao();


    public HomeViewModel(Application application, SavedStateHandle savedStateHandle) {
        super(application);
        this.savedStateHandle =savedStateHandle;
        Integer defaultFreq = 60;
        currentFreq = savedStateHandle.getLiveData("currentFreq", defaultFreq);
        currentId = savedStateHandle.getLiveData("currentId", 0);
        currentRecordId = savedStateHandle.getLiveData("currentRecordId");
        sensorManager = (SensorManager) application.getSystemService(Context.SENSOR_SERVICE);
        accSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
//        magSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

    }

    // for slider on change
    public void setCurrentFreq(int freq){
        currentFreq.setValue(freq);
        savedStateHandle.set("currentFreq", freq);
    }

    private void incCurrentId(){
        int id = currentId.getValue() + 1;
        currentId.setValue(id);
        savedStateHandle.set("currentId", id);
    }

    public void resetCurrentId(){
        int id = 0;
        currentId.setValue(id);
        savedStateHandle.set("currentId", id);
    }

    public void setCurrentRecordId(int id){
        currentRecordId.setValue(id);
        savedStateHandle.set("currentRecordId", id);
    }

    // for button on click
    public void startStopTimer(){
        if(isCollecting.getValue()){
            // stop timer
            stopCollecting();
            isCollecting.setValue(false);
            incCurrentId();
        }
        else{
            // start timer
            startCollecting();
            isCollecting.setValue(true);
        }
    }


    private void startCollecting(){
        currentSession = new Session(new Date(), currentFreq.getValue(), currentId.getValue());
        accData = new ArrayList<>();
        gyroData = new ArrayList<>();
        int sampleRateUs = 1000000 / currentFreq.getValue();
        // register sensors
        sensorManager.registerListener(this, accSensor, sampleRateUs,SensorManager.SENSOR_DELAY_GAME);
        sensorManager.registerListener(this, gyroSensor, sampleRateUs, SensorManager.SENSOR_DELAY_GAME);
    }

    private void stopCollecting(){
        sensorManager.unregisterListener(this);
        currentSession.setSensorData(accData, gyroData);
        sessionDao.insertSessions(currentSession);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        sensorManager.unregisterListener(this);
    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        SensorData data = new SensorData(sensorEvent.timestamp);
        data.setData(sensorEvent.values[0], sensorEvent.values[1], sensorEvent.values[2]);
        if(sensorEvent.sensor == accSensor){
            accData.add(data);
        }
        else if(sensorEvent.sensor == gyroSensor){
            gyroData.add(data);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) { }

    // write csv file
    public void sessionsToCsv(Uri dirUri){
        String accFilename = "";
        String gyroFilename = "";
        // create file
        DocumentFile documentFile = DocumentFile.fromTreeUri(getApplication(), dirUri);
        DocumentFile accFile = documentFile.createFile("text/csv", accFilename);
        DocumentFile gyroFile = documentFile.createFile("text/csv", gyroFilename);
        if(accFile == null || gyroFile == null){
            // TODO: file cannot be created
            return;
        }
        Session[] sessions = sessionDao.getAll();
        try {
            // acc
            String[] header = {"id", "freq", "timestamp", "X", "Y", "Z"};
            CSVWriter writer = new CSVWriter( new FileWriter(accFile.getUri().getPath()));
            writer.writeNext(header);
            for(Session session : sessions){
                writer.writeAll(session.formatAccData());
            }
            writer.close();

            // gyro
            writer = new CSVWriter( new FileWriter(gyroFile.getUri().getPath()));
            writer.writeNext(header);
            for(Session session : sessions){
                writer.writeAll(session.formatGyroData());
            }
            writer.close();

            sessionDao.deleteSessions(sessions);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}