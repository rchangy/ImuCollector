package com.example.imucollector.ui.home;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;

import com.example.imucollector.R;
import com.example.imucollector.databinding.FragmentHomeBinding;
import com.google.android.material.slider.Slider;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private FragmentHomeBinding binding;
    private Slider sliderFreq;
    private final Slider.OnChangeListener changeListener = new Slider.OnChangeListener() {
        @Override
        public void onValueChange(@androidx.annotation.NonNull Slider slider, float value, boolean fromUser) {
            homeViewModel.setCurrentFreq((int) value);
        }
    };

    private NumberPicker numberPicker;
    private NumberPicker.OnValueChangeListener changeListenerNumberPicker = new NumberPicker.OnValueChangeListener() {
        @Override
        public void onValueChange(NumberPicker numberPicker, int i, int i1) {
            homeViewModel.setCurrentRecordId(i1);
        }
    };

    // export file
    private static final int OPEN_DOCUMENT_TREE = 1;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider((ViewModelStoreOwner) this, new ViewModelProvider.AndroidViewModelFactory(getActivity().getApplication())).get(HomeViewModel.class);
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false);
        View root = binding.getRoot();
        return root;
    }

    @Override
    public void onViewCreated(@NonNull @androidx.annotation.NonNull View view, @Nullable @androidx.annotation.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setHomeViewModel(homeViewModel);
        binding.setLifecycleOwner(getViewLifecycleOwner());
        sliderFreq = binding.sliderFreq;
        sliderFreq.addOnChangeListener(changeListener);
        numberPicker = binding.numberPickerRecordId;
        numberPicker.setOnValueChangedListener(changeListenerNumberPicker);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void startStopTimer(View view){
        numberPicker.setEnabled(homeViewModel.isCollecting.getValue());
        homeViewModel.startStopTimer();
    }

    public void resetSessionId(View view){
        homeViewModel.resetCurrentId();
    }

    private void chooseExportDirectory(){
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);

        // Optionally, specify a URI for the directory that should be opened in
        // the system file picker when your app creates the document.
        // TODO: initial uri
//        intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, uriToLoad);

        startActivityForResult(intent, OPEN_DOCUMENT_TREE);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == OPEN_DOCUMENT_TREE && resultCode == Activity.RESULT_OK){
            Uri uri = null;
            if(data != null){
                uri = data.getData();
                homeViewModel.sessionsToCsv(uri);
            }
        }
    }
}